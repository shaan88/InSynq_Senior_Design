For the video the robots seem slow. This is becasue of the node data structure, speed control and obstacles. When one of the robots sense an obtacle all the other robots that has less priority than it must also stop. This is 
very apparent espically with the robots that starts on lower left and right. The right robot senses an obstacles so the left robot must also stop until that obstacles passes. 

Also if an obstacle and robot overlap it dosen't mean it crashed, the two are just in very close proximity to each other as if the person is "passing by" near the robot.